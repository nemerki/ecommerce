<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-6">Eticaret Yazılımı &copy; 2017</div>
            <div class="col-md-6 text-right"><a href="http://www.uzaktankurs.com">Uzaktan Kurs</a></div>
        </div>
    </div>
</footer>
