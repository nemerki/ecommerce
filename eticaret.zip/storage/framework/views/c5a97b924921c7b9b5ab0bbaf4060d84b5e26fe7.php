<?php $__env->startSection("tittle"); ?>
<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="bg-content">
            <a href="<?php echo e(route("frontend.order.index")); ?>" class="btn btn-primary btn-xs">
                <i class="glyphicon glyphicon-arrow-left"></i>Siparişlere Dön
            </a>
            <h2>Sipariş (SP-<?php echo e($order->id); ?>)</h2>
            <table class="table table-bordererd table-hover">
                <tr>
                    <th colspan="1">Ürün</th>
                    <th>Tutar</th>
                    <th>Adet</th>
                    <th>Ara Toplam</th>
                    <th>Durum</th>
                </tr>
                <?php $__currentLoopData = $order->basket->basket_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sepetdeki_urun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width: 120px;">
                            <a href="<?php echo e(route('frontend.product.index',['id'=>$sepetdeki_urun->product->id,'slug'=>$sepetdeki_urun->product->slug])); ?>">
                                <img src="https://loremflickr.com/120/100/product?random=<?php echo e(rand(1,100)); ?>" alt="...">
                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(route('frontend.product.index',['id'=>$sepetdeki_urun->product->id,'slug'=>$sepetdeki_urun->product->slug])); ?>">
                                <?php echo e($sepetdeki_urun->product->tittle); ?>

                            </a>
                        </td>
                        <td><?php echo e($sepetdeki_urun->price); ?></td>
                        <td><?php echo e($sepetdeki_urun->qty); ?></td>
                        <td><?php echo e($sepetdeki_urun->price*$sepetdeki_urun->qty); ?></td>
                        <td><?php echo e($sepetdeki_urun->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th colspan="5" class="text-right">Tutar</th>
                    <th colspan="1"><?php echo e($order->amount); ?></th>
                    <th></th>
                </tr>

                <tr>
                    <th colspan="5" class="text-right">KDV</th>
                    <th colspan="1"><?php echo e($order->amount*((config('cart.tax'))/100)); ?></th>
                    <th></th>
                </tr>
                <tr>
                    <th colspan="5" class="text-right">Toplam Tutar</th>
                    <th colspan="1"><?php echo e($order->amount+$order->amount*((config('cart.tax'))/100)); ?></th>
                    <th></th>
                </tr>

                
                
                
                
                

                <tr>
                    <th colspan="5" class="text-right">Sipariş Durum</th>
                    <th colspan="1"><?php echo e($order->status); ?></th>
                    <th></th>
                </tr>


            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>


<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>