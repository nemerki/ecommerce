<?php $__env->startSection("tittle"); ?>
<?php $__env->startSection("content"); ?>

    <div class="container">

        <ol class="breadcrumb">
            <li><a href="<?php echo e(route('frontend.home.index')); ?>">Anasayfa</a></li>
            <li class="active">Arama Sonucu</li>
            <li class="active"><?php echo e($search); ?></li>
        </ol>

        <div class="products bg-content">
            <div class="row">
                <?php if(count($products)==0): ?>
                    <div class="col-md-12 text-center">
                        Bir ürün bulunamadı!
                    </div>
                <?php endif; ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 product">
                        <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>">
                            <img src="https://loremflickr.com/260/300/aliexpress?random=<?php echo e(rand(1,100)); ?>"
                                 alt="<?php echo e($product->tittle); ?>">
                        </a>
                        <p>
                            <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>">
                                <?php echo e($product->tittle); ?>

                            </a>
                        </p>
                        <p class="price"><?php echo e($product->price); ?> ₺</p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($products->appends(["search"=>old("search")])->links()); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>


<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>