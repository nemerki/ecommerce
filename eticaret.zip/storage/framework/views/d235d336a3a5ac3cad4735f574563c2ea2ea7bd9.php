<?php $__env->startSection("tittle",$category->name); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="<?php echo e(route("frontend.home.index")); ?>">Anasayfa</a></li>
            <li class="active"><?php echo e($category->name); ?></li>
        </ol>
        <div class="row">
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading"><?php echo e($category->name); ?></div>
                    <div class="panel-body">
                        <?php if(count($altcategories)!=0): ?>
                            <h3>Alt Kategoriler</h3>
                            <div class="list-group categories">
                                <?php $__currentLoopData = $altcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $altcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route("frontend.category.index",["slug"=>$altcategory->slug])); ?>"
                                       class="list-group-item"><i class="fa fa-television"></i><?php echo e($altcategory->name); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <h3>Fiyat Aralığı</h3>
                        <form>
                            <div class="form-group">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> 100-200
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> 200-300
                                    </label>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="products bg-content">
                    <?php if(count($products) !=0): ?>
                        Sırala
                        <a href="?order=coksatan" class="btn btn-default">Çok Satanlar</a>
                        <a href="?order=yeni" class="btn btn-default">Yeni Ürünler</a>
                        <hr>
                    <?php endif; ?>
                    <div class="row">
                        <?php if(count($products) == 0): ?>
                            <div class="col-md-12">
                                Bu Kategoride Ürün bulunamadı
                            </div>
                        <?php else: ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 product">
                                    <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><img
                                            src="http://via.placeholder.com/350x150?text=Ürün Resmi"></a>
                                    <p>
                                        <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><?php echo e($product->tittle); ?></a>
                                    </p>
                                    <p class="price"><?php echo e($product->price); ?></p>
                                    <p><a href="#" class="btn btn-theme">Sepete Ekle</a></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <?php echo e(request()->has("order")? $products->appends(["order"=>request("order")])->links(): $products->links()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>


<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>