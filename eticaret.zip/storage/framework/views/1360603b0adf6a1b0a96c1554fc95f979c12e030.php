<?php $__env->startSection("tittle"); ?>
<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="jumbotron text-center">
            <h1>404</h1>
            <h2>Aradığınız Sayfa Bulunamadı</h2>
            <a href="<?php echo e(route("frontend.home.index")); ?>" class="btn btn-success">Anasayfaya Dön</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>


<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>