<?php $__env->startSection("tittle","Siparişler"); ?>
<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="bg-content">
            <h2>Siparişler</h2>
            <?php if(count($orders)==0): ?>
                <p>Henüz siparişiniz yok</p>
            <?php else: ?>
                <table class="table table-bordererd table-hover">
                    <tr>
                        <th>Sipariş Kodu</th>
                        <th>Sipariş Tarihi</th>
                        <th>Tutar</th>
                        <th>Toplam Ürün</th>
                        <th>Durum</th>
                        <th>İşlem</th>
                    </tr>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>SP-<?php echo e($order->id); ?></td>
                            <td><?php echo e(date("d-M-Y",strtotime($order->created_at))); ?></td>
                            <td><?php echo e($order->amount*((100+config('cart.tax'))/100)); ?></td> 
                            <td><?php echo e($order->basket->sepet_urun_adet()); ?></td>
                            <td><?php echo e($order->status); ?></td>
                            <td><a href="<?php echo e(route("frontend.order.detail",["id"=>$order->id])); ?>"
                                   class="btn btn-sm btn-success">Detay</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>


<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>