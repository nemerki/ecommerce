<?php $__env->startSection("content"); ?>
    <div class="container">
        <ol class="breadcrumb">
            <li><a href="#">Anasayfa</a></li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route("frontend.category.index",["slug"=>$category->slug])); ?>"><?php echo e($category->name); ?></a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="active">Kategori</li>
        </ol>
        <div class="bg-content">
            <div class="row">
                <div class="col-md-5">
                    <img src="https://loremflickr.com/450/300/product?random=<?php echo e(rand(1,100)); ?>" alt="...">
                    <hr>
                    <div class="row">
                        <div class="col-xs-3">
                            <a href="#" class="thumbnail"> <img src="https://loremflickr.com/150/150/product?random=<?php echo e(rand(1,100)); ?>" alt="..."></a>
                        </div>
                        <div class="col-xs-3">
                            <a href="#" class="thumbnail"><img src="https://loremflickr.com/150/150/product?random=<?php echo e(rand(1,100)); ?>" alt="..."></a>
                        </div>
                        <div class="col-xs-3">
                            <a href="#" class="thumbnail"><img src="https://loremflickr.com/150/150/product?random=<?php echo e(rand(1,100)); ?>" alt="..."></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <h1><?php echo e($product->tittle); ?></h1>
                    <p class="price"><?php echo e($product->price); ?></p>
                    <form action="javascript:void(0);">
                        <p>
                            <button type="btn" data-id="<?php echo e($product->id); ?>" id="addToBasket" class="btn btn-theme">Sepete
                                Ekle
                            </button>
                        </p>
                    </form>
                </div>
            </div>

            <div>
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active"><a href="#t1" data-toggle="tab">Ürün Açıklaması</a></li>
                    <li role="presentation"><a href="#t2" data-toggle="tab">Yorumlar</a></li>
                </ul>
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane active" id="t1"><?php echo e($product->description); ?></div>
                    <div role="tabpanel" class="tab-pane" id="t2">t2</div>
                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>
    <script>
        $("#addToBasket").on("click", function () {
            var button = $(this);

            $(".has-error").removeClass("has-error");
            $(".label-danger").remove();

            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });

            $.ajax({
                type: "post",
                url: "<?php echo e(route("frontend.basket.add")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: button.data("id"),

                },
                success: function (response) {
                    swal.close();
                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });


                },
                error: function (response) {
                    swal.close();

                    $.each(response.responseJSON.errors, function (k, v) {
                        $.each(v, function (kk, vv) {
                            $("[name='" + k + "']").parent().addClass("has-error");
                            $("[name='" + k + "']").parent().append(" <span class=\"label label-danger\">" + vv + "</span>");
                        })
                    });

                }
            })
        })
    </script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>