<?php $__env->startSection("tittle","Sepet"); ?>
<?php $__env->startSection("content"); ?>
    <div class="container">
        <div class="bg-content">
            <h2>Sepet</h2>
            <?php if(count(Cart::content())>0): ?>
                <table class="table table-bordererd table-hover">
                    <tr>
                        <th colspan="2">Ürün</th>
                        <th>Adet Fiyat</th>
                        <th>Adet</th>
                        <th>Tutar</th>
                        <th>İşlem</th>

                    </tr>

                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 120px">
                                <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,'slug'=>$product->options->slug])); ?>">
                                    <img src="https://loremflickr.com/120/100/product?random=<?php echo e(rand(1,100)); ?>" alt="...">
                                </a>
                            </td>

                            <td>
                                <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,'slug'=>$product->options->slug])); ?>">
                                    <?php echo e($product->name); ?>

                                </a>
                            </td>
                            <td><?php echo e($product->price); ?></td>
                            <td>
                                <a href="#" data-id="<?php echo e($product->rowId); ?>" data-qty="<?php echo e($product->qty-1); ?>"
                                   class="btn btn-xs btn-default productDecrease">-</a>
                                <span style="padding: 10px 20px"><?php echo e($product->qty); ?></span>
                                <a href="#" data-id="<?php echo e($product->rowId); ?>" data-qty="<?php echo e($product->qty+1); ?>"
                                class="btn btn-xs btn-default productIncrease">+</a>
                            </td>
                            <td><?php echo e($product->subtotal); ?></td>
                            <td>
                                <form action="javascript:void(0);">
                                    <button class="btn btn-danger basketItemDelete" data-id="<?php echo e($product->rowId); ?>">
                                        Sil
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th colspan="4">Alt Toplam</th>
                        <th><?php echo e(Cart::subtotal()); ?></th>
                    </tr>
                    <tr>
                        <th colspan="4">KDV</th>
                        <th><?php echo e(Cart::tax()); ?></th>
                    </tr>
                    <tr>
                        <th colspan="4">Genel Toplam</th>
                        <th><?php echo e(Cart::total()); ?></th>
                    </tr>
                </table>

                <div>
                    <form action="javascript:void(0);">
                        <button class="btn btn-info pull-left" id="basketDestroy">
                            Sepeti Boşalt
                        </button>
                    </form>

                    <a href="<?php echo e(route("frontend.payment.index")); ?>" class="btn btn-success pull-right btn-lg">Ödeme Yap</a>
                </div>

            <?php else: ?>
                <p>Sepetinizde Ürün Yok</p>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>
    <script>

        $(".productIncrease, .productDecrease").on("click", function () {
            var button = $(this);
            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });
            $.ajax({
                type: "post",
                url:"<?php echo e(route("frontend.basket.qtyUpdate")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: button.data("id"),
                    qty: button.data("qty"),
                },
                success: function (response) {
                    swal.close();

                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });
                    location.reload();
                },
                error: function (response) {
                    swal.close();
                }
            })
        })

        $(".basketItemDelete").on("click", function () {
            var button = $(this);

            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });
            $.ajax({
                type: "post",
                url: "<?php echo e(route("frontend.basket.delete")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    id: button.data("id")
                },
                success: function (response) {
                    if (response.status == "success") {
                        button.closest("tr").remove();
                    }
                    swal.close();
                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });
                    location.reload();
                },
                error: function (response) {
                    swal.close();
                    console.log(response);
                }
            })
        })


        $("#basketDestroy").on("click", function () {

            swal({
                title: 'Yükleniyor...',
                html:
                '<i class="fa fa-circle-o-notch fa-spin fa-3x fa-fw"></i>' +
                ' <span class="sr-only">Loading...</span>',
                showCloseButton: false,
                showCancelButton: false,
                showConfirmButton: false,
                allowOutsideClick: false
            });
            $.ajax({
                type: "post",
                url: "<?php echo e(route("frontend.basket.destroy")); ?>",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>"

                },
                success: function (response) {

                    swal.close();
                    swal({
                        type: response.status,
                        title: response.title,
                        text: response.message,
                        timer: 2000
                    });
                    location.reload();
                },
                error: function (response) {
                    swal.close();
                    console.log(response);
                }
            })
        })
    </script>



<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>