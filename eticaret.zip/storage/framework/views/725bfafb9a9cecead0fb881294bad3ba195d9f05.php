<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">

<head>
    <title><?php echo $__env->yieldContent('tittle', config('app.name')); ?></title>
    <?php echo $__env->make("layouts.include.frontend.head", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldPushContent("customCss"); ?>
</head>

<body id="commerce">
<?php echo $__env->make("layouts.include.frontend.navbar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent("content"); ?>
<?php echo $__env->make("layouts.include.frontend.footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/sweetalert2@7.21.0/dist/sweetalert2.all.js"></script>
<?php echo $__env->yieldPushContent("customJs"); ?>
</body>

</html>
