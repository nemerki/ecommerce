<h1><?php echo e(config("app.name")); ?></h1>
<p>Kaydınız başarılı bir Şekilde yapıldı.</p>
<p>Hoşgeldin <?php echo e($user->name); ?></p>
<p>Kaydınızı Aktifleşdirmek için <a href="<?php echo e(config("app.url")); ?>/kullanici/aktiflesdir/<?php echo e($user->activation_key); ?>">tıklayın</a> veya aşağıdaki bağlantıyı açın</p>
<p><?php echo e(config("app.url")); ?>/kullanici/aktiflesdir/<?php echo e($user->activation_key); ?></p>
