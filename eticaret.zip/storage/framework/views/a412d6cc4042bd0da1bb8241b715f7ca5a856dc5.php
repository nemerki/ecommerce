<!--sidebar-menu-->
<div id="sidebar">
    <a href="<?php echo e(route("backend.home.index")); ?>" class="visible-phone"><i class="icon icon-home"></i> Yönetim Paneli</a>
    <ul>
        <li class="active"><a href="<?php echo e(route("backend.home.index")); ?>"><i
                    class="icon icon-home"></i><span>Yönetim Paneli</span></a></li>
        <li><a target="_blank" href="<?php echo e(route("frontend.home.index")); ?>"><i
                    class="icon icon-home"></i><span>Anasayfa</span></a></li>
        <li><a href="<?php echo e(route("backend.user.index")); ?>"><i class="icon icon-user"></i><span>Kullanıcılar</span></a>
        </li>


    </ul>
</div>
<!--sidebar-menu-->
