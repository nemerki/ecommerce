<?php $__env->startSection("content"); ?>


    <div class="container">


        <?php if(session()->has('mesaj')): ?>
            <div class="alert alert-<?php echo e(session('mesaj_tur')); ?>"><?php echo e(session('mesaj')); ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">Kategoriler</div>
                    <div class="list-group categories">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route("frontend.category.index",["slug"=>$category->slug])); ?>"
                               class="list-group-item"><i class="fa fa-television"></i> <?php echo e($category->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li data-target="#carousel-example-generic" data-slide-to="<?php echo e($index); ?>"
                                class=" <?php echo e($index==0 ? 'active':''); ?>"></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                    <div class="carousel-inner" role="listbox">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item <?php echo e($index==0 ? 'active':''); ?>">
                                <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>">
                                    <img src="https://loremflickr.com/640/400/product?random=<?php echo e(rand(1,100)); ?>" alt="..."></a>
                                <div class="carousel-caption">
                                    <?php echo e($product->tittle); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel panel-default" id="sidebar-product">
                    <div class="panel-heading">Günün Fırsatı</div>
                    <div class="panel-body">
                        <a href="<?php echo e(route("frontend.product.index",["id"=>$gunun_firsati->id,"slug"=>$gunun_firsati->slug])); ?>">
                            <img src="https://picsum.photos/260/300/?random" class="img-responsive">
                            <?php echo e($gunun_firsati->tittle); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="products">
            <div class="panel panel-theme">
                <div class="panel-heading">Öne Çıkan Ürünler</div>
                <div class="panel-body">
                    <div class="row">
                        <?php $__currentLoopData = $one_cikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 product">
                                <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><img
                                        src="https://loremflickr.com/260/300/discount?random=<?php echo e(rand(1,100)); ?>"></a>
                                <p>
                                    <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><?php echo e($product->tittle); ?></a>
                                </p>
                                <p class="price"><?php echo e($product->price); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <hr>
        <div class="products">
            <div class="panel panel-theme">
                <div class="panel-heading">Çok Satan Ürünler</div>
                <div class="panel-body">
                    <div class="row">
                        <?php $__currentLoopData = $cok_satan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 product">
                                <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><img
                                        src="https://loremflickr.com/260/300/technology?random=<?php echo e(rand(1,100)); ?>"></a>
                                <p>
                                    <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><?php echo e($product->tittle); ?></a>
                                </p>
                                <p class="price"><?php echo e($product->price); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="products">
            <div class="panel panel-theme">
                <div class="panel-heading">İndirimli Ürünler</div>
                <div class="panel-body">
                    <div class="row">
                        <?php $__currentLoopData = $indirimli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3 product">
                                <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><img
                                        src="https://loremflickr.com/260/300/car?random=<?php echo e(rand(1,100)); ?>"></a>
                                <p>
                                    <a href="<?php echo e(route("frontend.product.index",["id"=>$product->id,"slug"=>$product->slug])); ?>"><?php echo e($product->tittle); ?></a>
                                </p>
                                <p class="price"><?php echo e($product->price); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("customJs"); ?>

    <script>
        setTimeout(function () {
            $(".alert").slideUp(500);
        }, 3000)
    </script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush("customCss"); ?>



<?php $__env->stopPush(); ?>


<?php echo $__env->make("layouts.frontend", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>